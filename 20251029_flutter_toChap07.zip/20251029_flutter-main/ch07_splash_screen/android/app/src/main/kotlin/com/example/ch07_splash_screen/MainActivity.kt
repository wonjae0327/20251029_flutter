package com.example.ch07_splash_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
