package com.example.dart_basic

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
