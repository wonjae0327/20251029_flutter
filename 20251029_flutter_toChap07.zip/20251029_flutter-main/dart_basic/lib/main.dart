import 'package:flutter/material.dart';

// 다트는 프로그램 시작적인 엔트리 함수 기호로 main()를 사용
void main() {

}
