class Person {
  // '_'로 시작한 변수는 같은 파일 내부에서는 접근 가능, 외부는 불가
  int _pno;
  Person(this._pno);
}