package com.example.ch06_widgets

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
